﻿namespace PoGo.NecroBot.Logic.Model
{
    public enum PokemonGrades
    {
        VeryCommon,
        Common,
        Popular, //Uncommon
        Rare,
        VeryRare,
        Special,
        Epic,
        Legendary
    }
}