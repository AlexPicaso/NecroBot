namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class Geo
    {
        public float lat { get; set; }
        public float lng { get; set; }
    }
}