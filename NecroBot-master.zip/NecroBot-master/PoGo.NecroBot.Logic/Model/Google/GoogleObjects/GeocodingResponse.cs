﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class GeocodingResponse
    {
        public Result[] results { get; set; }
        public string status { get; set; }
    }
}