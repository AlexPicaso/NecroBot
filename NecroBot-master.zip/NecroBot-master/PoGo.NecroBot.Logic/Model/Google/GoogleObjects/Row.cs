﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class Row
    {
        public Element[] elements { get; set; }
    }
}