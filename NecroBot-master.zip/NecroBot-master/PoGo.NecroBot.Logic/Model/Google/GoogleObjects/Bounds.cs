﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class Bounds
    {
        public Geo northeast { get; set; }
        public Geo southwest { get; set; }
    }
}