﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class Address_Components
    {
        public string long_name { get; set; }
        public string short_name { get; set; }
        public string[] types { get; set; }
    }
}