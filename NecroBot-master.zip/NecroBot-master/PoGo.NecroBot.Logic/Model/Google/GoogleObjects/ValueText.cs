﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class ValueText
    {
        public string text { get; set; }
        public int value { get; set; }
    }
}