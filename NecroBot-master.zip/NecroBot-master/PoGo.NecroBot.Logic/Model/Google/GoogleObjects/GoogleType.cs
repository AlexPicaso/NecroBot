﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public enum GoogleType
    {
        DistanceMatrix = 1,
        Directions = 2
    }
}