﻿namespace PoGo.NecroBot.Logic.Model.Google.GoogleObjects
{
    public class Element
    {
        public ValueText distance { get; set; }
        public ValueText duration { get; set; }
        public ValueText duration_in_traffic { get; set; }
        public string status { get; set; }
    }
}