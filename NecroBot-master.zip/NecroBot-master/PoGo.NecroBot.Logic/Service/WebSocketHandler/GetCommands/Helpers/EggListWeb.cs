﻿namespace PoGo.NecroBot.Logic.Service.WebSocketHandler.GetCommands.Helpers
{
    internal class EggListWeb
    {
        public object Incubators { get; set; }
        public object UnusedEggs { get; set; }
    }
}