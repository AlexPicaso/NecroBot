﻿namespace PoGo.NecroBot.Logic.Service.WebSocketHandler.GetCommands.Helpers
{
    internal class ConfigWeb
    {
        public object AuthJson { get; set; }
        public object AuthSchemaJson { get; set; }
        public object ConfigJson { get; set; }
        public object ConfigSchemaJson { get; set; }
    }
}