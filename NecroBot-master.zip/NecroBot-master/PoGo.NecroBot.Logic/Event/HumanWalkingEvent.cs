﻿namespace PoGo.NecroBot.Logic.Event
{
    public class HumanWalkingEvent : IEvent
    {
        public double OldWalkingSpeed;
        public double CurrentWalkingSpeed;
    }
}