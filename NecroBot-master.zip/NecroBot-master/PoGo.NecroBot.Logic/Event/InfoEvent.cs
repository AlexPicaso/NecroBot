﻿namespace PoGo.NecroBot.Logic.Event
{
    public class InfoEvent: IEvent
    {
        public string Message { get; set; }
        public InfoEvent()
        {
        }
    }
}
