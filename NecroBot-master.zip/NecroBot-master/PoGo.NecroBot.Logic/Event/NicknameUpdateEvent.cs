﻿namespace PoGo.NecroBot.Logic.Event
{
    public class NicknameUpdateEvent : IEvent
    {
        public string Nickname = "";
    }
}