﻿namespace PoGo.NecroBot.Logic.Event
{
    public class LogEvent : IEvent
    {
        public string Message;
        public string Color;
    }
}