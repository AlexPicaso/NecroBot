﻿using System.Windows.Controls;

namespace PoGo.NecroBot.Window.Controls.Sidebars
{
    /// <summary>
    /// Interaction logic for CatchPokemonItem.xaml
    /// </summary>
    public partial class CatchPokemonItem : UserControl
    {
        public CatchPokemonItem()
        {
            InitializeComponent();
        }
    }
}
