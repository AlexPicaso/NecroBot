﻿using System.Windows.Controls;

namespace PoGo.NecroBot.Window.Controls.Sidebars
{
    /// <summary>
    /// Interaction logic for PokestopItem.xaml
    /// </summary>
    public partial class PokestopItem : UserControl
    {
        public PokestopItem()
        {
            InitializeComponent();
        }
    }
}
