﻿using System.Windows.Controls;

namespace PoGo.NecroBot.Window.Controls
{
    /// <summary>
    /// Interaction logic for Sidebar.xaml
    /// </summary>
    public partial class SidebarControl : UserControl
    {
        public SidebarControl()
        {
            InitializeComponent();
        }
    }
}
