﻿namespace PoGo.NecroBot.Window.Model
{
    public class SidebarItemViewModel   : ViewModelBase
    {
        public string UUID { get; set; }
    }
}
